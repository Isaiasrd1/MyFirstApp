package com.example.myfirstapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView

class CircActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_circ)
    }
    fun calcularRaio(view: View) {
        //ENTRADA
        val editTextRaio = findViewById<EditText>(R.id.etRaio)
        val raio = editTextRaio.text.toString().toDouble()

        //PROCESSAMENTO
        val diam = raio * 2

        val comp = 2 * 3.14 * raio

        val area = 3.14 * raio * raio



        //SAIDA
        val textView = findViewById<TextView>(R.id.tvResult).apply {
            //text = message
            text = String.format("O diâmetro é:" + diam)
        }
        val textView2 = findViewById<TextView>(R.id.tvResult2).apply {
            //text = message
            text = String.format("O comprimento é:" + comp)
        }
        val textView3 = findViewById<TextView>(R.id.tvResult3).apply {
            //text = message
            text = String.format("A área é:" + area)
        }

        findViewById<TextView>(R.id.tvMessage).apply {
            //text = message
            text = "RESULTADOS:"
        }
    }
}

