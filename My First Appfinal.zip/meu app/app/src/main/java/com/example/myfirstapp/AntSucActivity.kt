package com.example.myfirstapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView

class AntSucActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ant_suc)
    }

    fun calcularNum(view: View) {
        //ENTRADA
        val editTextNum = findViewById<EditText>(R.id.etNum)
        val Num = editTextNum.text.toString().toInt()

        //PROCESSAMENTO
        val NumSuc = Num + 1

        val NumAnt = Num - 1

        //SAIDA
        val textView = findViewById<TextView>(R.id.tvResult).apply {
            //text = message
            text = String.format("O sucessor é: " + NumSuc)
        }
        val textView2 = findViewById<TextView>(R.id.tvResult2).apply {
            //text = message
            text = String.format("O antecessor é: " + NumAnt)
        }
        findViewById<TextView>(R.id.tvMessage).apply {
            //text = message
            text = "RESULTADOS:"
        }
    }
}